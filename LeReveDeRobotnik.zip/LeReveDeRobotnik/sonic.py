import pygame

def main():
    #start here
    return

if __name__ == "__main__":
    main()