class Bot(object):

    def __init__(self):
        pass

    def act(self, xdif, ydif, vel):
        pass